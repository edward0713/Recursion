/*
Edward Franco(6238682)
Course:COP3804 Intermediate Java
Professor Charters
*/


package recursion;

import java.util.Scanner;
public class Recursion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Enter a string input: ");
        String input = keyboard.nextLine();
        System.out.println(ChangeXY(input));
            
        
        System.out.println("Would you like to add another input? Yes or No.");
            input = keyboard.nextLine();
            
            while (input.equalsIgnoreCase("yes"))
        {
            System.out.println("Enter a string input:");
            input = keyboard.nextLine();
            System.out.println(ChangeXY(input));
            System.out.println("Would you like to add another input? Yes or No.");
            input = keyboard.nextLine();
        }
            
            if (input.equalsIgnoreCase("no"))
            {
                System.out.println("Ok, Goodbye.");
            }
            else
            {
             System.out.println("That is not a valid input.");
            }
        
            }
    
    public static String ChangeXY(String str) {

  // when to stop, this is the base case.
  if (str.length() == 0){
    return str;
  }

  // handles the "special case" using an assumption we can solve str.substring(1)
  if (str.charAt(0) == 'x'){
    return 'y' + ChangeXY(str.substring(1)); //recursively exchanges 'x' for 'y'  
  }
  // handle the "simple" case using an assumption we can solve str.substring(1)
  return str.charAt(0) + ChangeXY(str.substring(1)); //returns the character at the index 0(first letter) and calls the ChangeXY method
                                                     //inside ChangeXY uses the substring which swaps positions from index 0 to index 1
}

}
